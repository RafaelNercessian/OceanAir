<?php

$mod_strings['LBL_UPDATE_CONTACTS'] = 'Update Contacts';